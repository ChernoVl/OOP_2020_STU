package sk.example.exam.domain.componens;

public enum Nationality {
    USA,
    ZSSR,
    Germany,
    GreatBritain
}
