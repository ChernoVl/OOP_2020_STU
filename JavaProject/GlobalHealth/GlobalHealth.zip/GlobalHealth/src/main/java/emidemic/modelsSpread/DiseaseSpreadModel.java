package emidemic.modelsSpread;

public interface DiseaseSpreadModel {
}
