package emidemic.comunication;

public class FRead implements Read {
    //TODO
}
