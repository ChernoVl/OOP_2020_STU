package emidemic.comunication;

public interface Read {
        //TODO

}
