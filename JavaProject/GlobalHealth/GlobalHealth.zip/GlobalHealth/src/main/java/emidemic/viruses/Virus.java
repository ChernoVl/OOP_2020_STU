package emidemic.viruses;

public interface Virus {
    int getCurability();
    void setCurability(int curability);
}
