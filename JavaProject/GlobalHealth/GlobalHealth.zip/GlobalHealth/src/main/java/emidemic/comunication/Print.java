package emidemic.comunication;

public interface Print {
    //TODO
}
