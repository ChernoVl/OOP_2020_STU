package emidemic.comunication;

public class ConsoleRead implements Read {
    //TODO
    public void setup(){

    }
}
