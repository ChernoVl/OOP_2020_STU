package emidemic.comunication;

public class Fprint implements Print {
    //TODO
}
