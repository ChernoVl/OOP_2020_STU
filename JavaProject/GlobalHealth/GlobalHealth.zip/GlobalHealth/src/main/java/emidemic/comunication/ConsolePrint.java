package emidemic.comunication;

public class ConsolePrint implements Print {
    //TODO
}
