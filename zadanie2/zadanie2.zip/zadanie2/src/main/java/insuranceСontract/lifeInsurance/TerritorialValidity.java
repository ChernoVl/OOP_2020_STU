package insuranceСontract.lifeInsurance;

/**
 * Územná platnosť (číselníková hodnota, povolené hodnoty sú: “Slovensko”,
 * “Svet”, “Svet + Slovensko”)
 */

public enum TerritorialValidity {
    SK,
    WORD,
    SK_WORD
}
