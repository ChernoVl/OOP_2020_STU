package insuranceСontract.lifeInsurance;

/**
 * účel cesty (číselníková hodnota, povolené sú: pracovne, rekreačne, šport, a
 * pod.)
 */

public enum TravelPurpose {
    WORK,
    RELAX,
    SPORT,
    OTHER
}
