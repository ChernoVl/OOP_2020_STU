package insuranceСontract.nonLifeInsurance;

/**
 * typ nehnuteľnosti (číselníková hodnota, povolené hodnoty sú: "Byt", "Rodinný
 * dom - murovaný", "Rodinný dom - drevený")
 */
public enum PropertyType {
    FLAT,
    BRICK_FamilyHouse,
    WOODEN_FamilyHouse
}
